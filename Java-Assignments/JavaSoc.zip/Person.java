import java.util.LinkedList;

/**
 * Creates users
 */
class Person {
    final String username;
    private String user_summary;
    private LinkedList<Person> followers, following, liked;
    private final InboxImplementation inbox;
    private final OutboxImplementation outbox;


    // CONSTRUCTORS
    /**
     * @param String username, user_summary
     * @return Nothing - variables set/created
     */
    Person(String username, String user_summary) {
        this.username = username;
        this.user_summary = user_summary;
        followers = new LinkedList<Person>();
        following = new LinkedList<Person>();
        liked = new LinkedList<Person>();
        inbox = new InboxImplementation();
        outbox = new OutboxImplementation();
    }



    // GETTERS AND SETTERS

    /**
     * @param Nothing
     * @return String - the user's username
     */
    public String toString() {return username;}



    /**
     * @param Nothing
     * @return String - Users username
     */
    public String getUsername() {return username;}


    /**
     * @param String user_summary
     * @return Nothing
    */
    public void setUser_Summary(String user_summary) {this.user_summary = user_summary;}
    
    /**
     * @param - Nothing
     * @return String - Users user_summary
     */
    public String getUserSummary() {return user_summary;}

    /**
     * @param Nothing
     * @return LinkedList<Person> - Users followers list
    */
    public LinkedList<Person> getFollowers() {return followers;}

    /**
     * @param Nothing
     * @return LinkedList<Person> - Users following list
    */
    public LinkedList<Person> getFollowing() {return following;}

    /**
     * @param Nothing
     * @return LinkedList<Person> - Users liked list
    */
    public LinkedList<Person> getLiked() {return liked;}

    /**
     * @param Nothing
     * @return LinkedList<Person> - Users inbox contents list
    */
    public Inbox getInbox() {return inbox;}

    /**
     * @param Nothing
     * @return LinkedList<Person> - Users outbox contents list
    */
    public Outbox getOutbox() {return outbox;}







    // FUNCTIONS

    /**
     * @param action - the action to be added
     * @return boolean - true if there is a message to be sent, false otherwise
     */
    public boolean toBeSent(Activity action) {
        if (outbox.send(action)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @param Nothing
     * @return boolean - true if the outbox contains a message, false otherwise
     */
    public boolean sendMessage() {
        try {
            outbox.deliverNext().send();
            return(true);
        }
        catch(Exception e) {
            return(false);
        }
    }

    /**
     * Reads the next item in the inbox (in an order of FIFO)
     * @return boolean - true if the method succeeds, false if it fails
     */
    public boolean readMessage() {
        try {
            inbox.readNext().open();
            return(true);
        }
        catch(Exception e) {
            return(false);
        }
    }
}
