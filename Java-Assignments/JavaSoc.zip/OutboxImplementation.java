import java.util.ArrayList;


class OutboxImplementation implements Outbox {
    ArrayList<Activity> outbox;

    // CONSTRUCTORS

    /**
     * @param Nothing
     * @return - outbox implementation
     */
    public OutboxImplementation() {
        outbox = new ArrayList<>();
    }



    /**
     * Function send() to be implemented from Outbox Interface
     * @param activity 
     * @return boolean - true if added, false otherwise
     */
    public boolean send(Activity activity) {
        return outbox.add(activity);
    }

    /**
     * Function deliverNext() to be implemented from Interface
     * @param Nothing
     * @return Last action - Pops action out of inbox (last action)
     */
    public Activity deliverNext() {
        if (outbox.isEmpty()) {
            System.err.println("Outbox is empty.");
            return null;
        }
        return outbox.remove(0);
    }

    /**
     * Function getCount()
     * @param Nothing
     * @return Integer - Counts actions
     */
    public int getCount() {
        return outbox.size();
    }
}
