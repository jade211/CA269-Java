class StreamObject {
    private String content;


    // CONSTRUCTORS 
    /**
     * @param String content
     * @return - Sets value
     */
    StreamObject(String content){
        this.content = content;
    }



    // GETTERS AND SETTERS
    /**
     * @param String content
     * @return Nothing - Sets value.
     */
    public void setContent(String content) {this.content = content;}
    
    
    /**
     * @param - Nothing
     * @return String content
     */
    public String getContent() {return content;}
}
