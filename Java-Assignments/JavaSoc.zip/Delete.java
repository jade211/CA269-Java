public class Delete extends ActivityFunctions {

    // CONSTRUCTORS
    /**
     * @param Person sending_user, Person receiving_user
     * @return Nothing - Sets values
     */
    public Delete(Person sending_user, Person receiving_user) {
        super(sending_user, receiving_user, sending_user + " has deleted a post!");
    }
}
