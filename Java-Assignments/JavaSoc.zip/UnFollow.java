public class UnFollow extends ActivityFunctions{


    // CONSTRUCTORS
    /**
     * @param Person sending_user, Person receiving_user
     * @return Nothing - Sets values
     */
    public UnFollow(Person sending_user, Person receiving_user) {
        super(sending_user, receiving_user, sending_user + " has stopped following " + receiving_user);
    }




    /**
     * open() function in this class adds the user to the followers list of the the other user
     * @param - Nothing 
     * @return boolean - true as user is added to the list successfully.
     */
    public boolean open() {
        receiving_user.getFollowers().remove(sending_user);
        return(super.open());
    }


    /**
     * send() function in this class removes the user from the following list of the the other user
     * @param - Nothing 
     * @return boolean - true as user is added to the list successfully.
     */
    public boolean send() {
        sending_user.getFollowing().remove(receiving_user);
        return super.send();
    }
}
