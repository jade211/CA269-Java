/**
 * Class that implements the functions found in App.java interfaces.
 * Class creates two account users and supplies a sample scenerio displaying interactions between the two.
 */
public class ClientApp implements App {
    private Person accountOne;

    /**
     * @param - Nothing
     * @return Inbox - contents of the users inbox
     */
    public Inbox getInbox() {return accountOne.getInbox();}

    /**
     * @param - Nothing
     * @return Outbox - contents of the accountOne's outbox
     */
    public Outbox getOutbox() {return accountOne.getOutbox();}

    /**
     * @param - nothing
     * @return String - Sample scenerio of the app working.
     */
    public String demo() {
        System.out.println("Checking UserName is implemented correctly");
        System.out.println("--Output--");
        Person accountOne = new Person("Jane Doe", "Sample Description User 1");
        Person accountTwo = new Person("John Doe", "Sample Description User 2");
        System.out.println("Account1 UserName: " + accountOne.getUsername());
        System.out.println("Account2 UserName: " + accountTwo.getUsername());

        System.out.println("\n-------------NEXT FEATURE-------------\n");


        System.out.println("Checking User Description is implemented correctly");
        System.out.println("--Output--");
        System.out.println("Account 1's Description: " + accountOne.getUserSummary());
        System.out.println("Account 2's Description: " + accountTwo.getUserSummary());

        System.out.println("\n-------------NEXT FEATURE-------------\n");


        System.out.println("Checking if Account 1 can Follow Account 2");
        System.out.println("--Output--");
        System.out.println(accountOne + " is following" + accountOne.getFollowing());
        accountOne.toBeSent(new Follow(accountOne, accountTwo)); // Using the same feature as sending a message paired with Follow()
        accountOne.sendMessage();
        accountTwo.readMessage();
        System.out.println(accountOne.username + " is following" + accountOne.getFollowing());
        System.out.println(accountTwo.username + " has followers" + accountTwo.getFollowers());
        
        System.out.println("\n-------------NEXT FEATURE-------------\n");


        System.out.println("Checking if Account 1 can Unfollow Account 2");
        System.out.println("--Output--");
        System.out.println(accountOne + " is following: " + accountOne.getFollowing());
        System.out.println(accountTwo + " has followers: " + accountTwo.getFollowers());
        accountOne.toBeSent(new UnFollow(accountOne, accountTwo));  // Using the same feature as sending a message paired with UnFollow function
        accountOne.sendMessage();
        accountTwo.readMessage();
        System.out.println(accountOne.username + " is following: " + accountOne.getFollowing());
        System.out.println(accountTwo.username + " has followers: " + accountTwo.getFollowers());

        System.out.println("\n-------------NEXT FEATURE-------------\n");




        System.out.println("Sending a message from Accout 1 to Account 2");
        accountOne.toBeSent(new Send(accountOne, accountTwo, "Test Message 123"));
        System.out.println("--Output--");
        accountOne.sendMessage();
        accountTwo.readMessage();

        System.out.println("\n-------------NEXT FEATURE-------------\n");


        System.out.println("Checking to see if Account 1 can Like Account 2");
        System.out.println("--Output--");
        accountOne.toBeSent(new Like(accountOne, accountTwo));
        accountOne.sendMessage();
        accountTwo.readMessage();
        System.out.println(accountTwo.username + " Profile Likes:" + accountTwo.getLiked());


        System.out.println("\n-------------NEXT FEATURE-------------\n");


        System.out.println("Checking if Account 2 can delete activity");
        System.out.println("--Output--");
        accountTwo.toBeSent(new Delete(accountTwo, accountOne));
        accountTwo.sendMessage();
        accountOne.readMessage();
    return "\n\nDone";
    }

    public static void main(String[] args) {
        ClientApp app = new ClientApp();
        System.out.println(app.demo());
    }
}

