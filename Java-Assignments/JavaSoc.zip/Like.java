public class Like extends ActivityFunctions {

    // CONSTRUCTORS
    /**
     * @param Person sending_user, Person receiving_user
     * @return Nothing - Sets values
     */
    public Like(Person sending_user, Person receiving_user) {
        super(sending_user, receiving_user, sending_user + " has liked " + receiving_user + "'s profile");
    }

    /**
     * open() function in this class adds the user to the liked list of the the other user
     * @param Nothing
     * @return boolean - true as user is added to the list successfully.
     */
    public boolean open() {
        receiving_user.getLiked().add(sending_user);
        return(super.open());
    }
}