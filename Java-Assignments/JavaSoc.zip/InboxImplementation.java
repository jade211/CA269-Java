import java.util.ArrayList;


class InboxImplementation implements Inbox {
    ArrayList<Activity> inbox;

    // CONSTRUCTORS
    /**
     * @param Nothing
     * @return -  inbox implementation
     */
    public InboxImplementation() {
        inbox = new ArrayList<>();
    }


    /**
     * Function receive() to be implemented from Interface
     * @param action
     * @return boolean - true if added, false otherwise
     */
    public boolean receive(Activity action) {
        if (action == null) {
            return false;
        }
        inbox.add(action);
        return true;
    }

    /**
     * Function readNext() to be implemented from Interface
     * @param Nothing
     * @return Last action - Pops action out of inbox (last action)
     */
    public Activity readNext() {
        if (inbox.isEmpty()) {
            System.err.println("Inbox is empty.");
            return null;
        }
        return inbox.remove(0);
    }

    /**
     * Function getCount() implemented from Inbox Interface
     * @param Nothing
     * @return Integer - Counts actions
     */
    public int getCount() {
        return inbox.size();
    }
}