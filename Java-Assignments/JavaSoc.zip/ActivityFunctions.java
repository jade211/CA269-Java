/**
 * Abstract class that will be used to implement the functions listed in the supplied 
 * Activity interface. Will be extended by the main functions of the app (Like, Follow, Unfollow, Create, Delete)
 */
public abstract class ActivityFunctions implements Activity{
    Person sending_user;
    Person receiving_user;
    StreamObject stream;



    // CONSTRUCTORS
    /**
     * @param - sending_user, receiving_user, stream
     * @return - Sets these values.
     */
    ActivityFunctions(Person sending_user, Person receiving_user, String message) {
        this.sending_user = sending_user;
        this.receiving_user = receiving_user;
        this.stream = new StreamObject(message);
    }



    // SETTERS AND GETTERS 
    /**
     * @param - nothing
     * @return - Person: Returns user that sent the message
     */
    public Person getSender() {return sending_user;}

    /**
     * @param - nothing
     * @return - Person: Returns user that received the message
     */
    public Person getReceiver() {return receiving_user;}

    /**
     * @param - nothing
     * @return SteamObject: Message
     */
    public StreamObject getStream() {return stream;}

    /**
     * Implementation of how to send a message
     * @param - Nothing
     * @return boolean - True/False depending on if message(s) exist
     */
    public boolean send() {
        Inbox inbox = receiving_user.getInbox();
        if (inbox != null) {
            inbox.receive(this);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Implementation of how to open a message
     * @param - Nothing
     * @return boolean - True/False depending on if message(s)is openable
     */
    public boolean open() {
        if (stream != null && sending_user != null && stream.getContent() != null) {
            System.out.println(sending_user + ": " + stream.getContent());
            return true;
        }
        return false;
    }
}
