/**
 * Sends messages
 */
public class Send extends ActivityFunctions {

    // CONSTRUCTORS
    /**
     @param Person sending_user, Person receiving_user, String message - message to be given with the activity
     */
    public Send(Person sending_user, Person receiving_user, String message) {
        super(sending_user, receiving_user, message);
    }
}